
import random

testSeed = int(input("Create a seed number: "))
random.seed(testSeed)
randomNumber = random.randint(0, 1)

if randomNumber == 0:
  print("Tail")
else:
  print("Head")

